const express = require('express');
const { signup, login, resetpassword, forgotpassword } = require('../controllers/auth.js');
const { contactus } = require('../controllers/contact.js');

const router=express.Router();
router.post('/signup',signup)
router.post('/login',login);
router.post('/contactus',contactus);
router.post('/forgotpassword',forgotpassword)
router.get('/resetpassword/:id/:token',resetpassword);
router.post('/resetpassword/:id/:token',resetpassword);


module.exports = router;
